import java.text.DecimalFormat;
import java.util.Scanner;

public class Aufgabe_2 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#.###");
        final double G = 9.80665;   //Fallbeschleunigung

        System.out.print("Geben Sie die Falldauer in ganzen Sekunden an: ");
        int zeit = scanner.nextInt();

        for(int i=1; i<=zeit; i+=5) {
            System.out.println("Zeit: " + i + " Sekunden");
            System.out.println("Strecke: " + df.format(streckenBerechnung(i,G)) + " meter");
            System.out.println();
        }
        scanner.close();
    }
    static double streckenBerechnung(int t, double G){
        return ((1f / 2) * G * Math.pow(t, 2));
    }
}
