import java.util.Scanner;

public class Aufgabe_3 {
    public static void main(String[] args) throws RuntimeException{
        Scanner scanner = new Scanner(System.in);
        System.out.print("Geben Sie eine natürliche Zahl ein: ");
        int maxzahl = scanner.nextInt();
        boolean primzahl;
        
        if (maxzahl < 1) {
            throw new RuntimeException(maxzahl+" ist keine natürliche Zahl!");
        }

        for (int zahl = 2; zahl <= maxzahl; zahl++) {     //gehe durch alle Zahlen von 2 bis zu der eingegeben Pruefzahl
            primzahl = true;
            for (int i = 2; i <= Math.sqrt(zahl); i++) {    //überprüfe, ob die Zahl eine Primzahl ist
                if ((zahl % i) == 0) {
                    primzahl = false;
                    break;
                }
            }
                   
            if (primzahl) {
                System.out.println("Die Zahl " + zahl + " ist eine Primzahl");
            } else {
                System.out.println("Die Zahl " + zahl + " ist keine Primzahl");
            }
        }
        scanner.close();
    }
}