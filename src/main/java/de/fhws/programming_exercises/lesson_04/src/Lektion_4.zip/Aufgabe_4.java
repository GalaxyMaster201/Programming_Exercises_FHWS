public class Aufgabe_4 {
    public static void main(String[] args){
        System.out.println("Fahrenheit:\t\tCelsius:");
        for (int temp=0; temp <= 300; temp++){
            System.out.printf("%5d\u2109",temp);    //Wert für °F
            System.out.print("\t\t\t");     //Platz zwischen den Werten für Fahrenheit und Celsius erstellen
            System.out.printf("%6.2f\u2103%n",fahrenheitToCelsius(temp));   //Wert für °C ausgeben
        }
    }

    //Methode um Fahrenheit in Celsius umzuwandeln
    public static float fahrenheitToCelsius(int fahrenheit){
        return ((5f/9)*(fahrenheit-32));
    }
}

// \u2109 = ℉
// \u2103 = ℃
// \t = Tabulator