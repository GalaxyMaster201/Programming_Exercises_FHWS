package programmieren_uebungen.lektion_9.src.exercise3;

public class Room{
    private final String roomName;
    private int maxNumber;
    private boolean occupied = false;

    /**
     * Constructor for the room object
     * @param roomName  name of the room
     * @param maxNumber maximum number of students
     */
    public Room(String roomName, int maxNumber){
         this.roomName = roomName;
         this.maxNumber = maxNumber;
    }

    // getter & setter for "occupied"
    public void setOccupied(boolean occupied){
        this.occupied = occupied;
    }
    public boolean isOccupied(){
        return occupied;
    }

    // getter for the room name
    public String getRoomName(){
        return roomName;
    }

    // getter for the max number of students
    public int getMaxNumber(){
        return maxNumber;
    }
}
