package lesson_13.src.exercise_1;

public class Main{
    public static void main(String[] args){
        Point p1 = new Point(6, 2, 3);
        System.out.println(p1);
        System.out.println(p1.calculateDistance());
    }
}
