package programmieren_uebungen.lektion_8.src.Exercise5;

public class Car{
    String brand;
    String name;
    String model;
    float displacement;
    String colour;
    int horsepower;
    String transmission;
    boolean convertible;
}
